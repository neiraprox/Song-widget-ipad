import SwiftUI

struct ContentView: View {
    @State private var isPlaying = false

    var body: some View {
        ZStack {
            LinearGradient(
                colors: [.black, Color(red: 0.08, green: 0.08, blue: 0.10)],
                startPoint: .top,
                endPoint: .bottom
            )
            .ignoresSafeArea()

            VStack(spacing: 22) {
                RoundedRectangle(cornerRadius: 24)
                    .fill(Color.white.opacity(0.10))
                    .frame(width: 260, height: 260)
                    .overlay(
                        Image(systemName: "music.note")
                            .font(.system(size: 70))
                            .foregroundStyle(.white.opacity(0.8))
                    )

                VStack(spacing: 6) {
                    Text("Song Widget")
                        .font(.title.bold())
                        .foregroundStyle(.white)

                    Text("Conecta Spotify para ver tu canción actual")
                        .font(.subheadline)
                        .foregroundStyle(.white.opacity(0.65))
                        .multilineTextAlignment(.center)
                }

                Button {
                    isPlaying.toggle()
                } label: {
                    Image(systemName: isPlaying ? "pause.fill" : "play.fill")
                        .font(.title2.bold())
                        .frame(width: 64, height: 64)
                        .background(.white, in: Circle())
                        .foregroundStyle(.black)
                }

                Text("Versión de prueba")
                    .font(.caption)
                    .foregroundStyle(.white.opacity(0.45))
            }
            .padding(30)
        }
    }
}
