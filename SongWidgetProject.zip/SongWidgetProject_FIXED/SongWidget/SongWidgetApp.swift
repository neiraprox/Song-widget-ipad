import SwiftUI

@main
struct SongWidgetApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
