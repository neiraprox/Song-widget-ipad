import WidgetKit
import SwiftUI

struct SongEntry: TimelineEntry {
    let date: Date
}

struct SongProvider: TimelineProvider {
    func placeholder(in context: Context) -> SongEntry {
        SongEntry(date: Date())
    }

    func getSnapshot(in context: Context, completion: @escaping (SongEntry) -> Void) {
        completion(SongEntry(date: Date()))
    }

    func getTimeline(in context: Context, completion: @escaping (Timeline<SongEntry>) -> Void) {
        let entry = SongEntry(date: Date())
        completion(Timeline(entries: [entry], policy: .after(Date().addingTimeInterval(900))))
    }
}

struct SongWidgetView: View {
    let entry: SongEntry

    var body: some View {
        ZStack {
            Color.black
            VStack(alignment: .leading, spacing: 8) {
                Image(systemName: "music.note")
                    .font(.title2)
                    .foregroundStyle(.white)
                Spacer()
                Text("Song Widget")
                    .font(.headline)
                    .foregroundStyle(.white)
                Text("Conecta Spotify")
                    .font(.caption)
                    .foregroundStyle(.white.opacity(0.65))
            }
            .padding()
        }
    }
}

struct SongWidget: Widget {
    let kind = "SongWidget"

    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: SongProvider()) { entry in
            SongWidgetView(entry: entry)
        }
        .configurationDisplayName("Song Widget")
        .description("Muestra la canción que estás escuchando.")
        .supportedFamilies([.systemSmall, .systemMedium, .systemLarge])
    }
}

@main
struct SongWidgetBundle: WidgetBundle {
    var body: some Widget {
        SongWidget()
    }
}
